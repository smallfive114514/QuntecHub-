<?php
// 配置示例文件。安装向导会复制本文件为 config.php 并填入你输入的数据库信息。
return [
    'db' => [
        'host'    => 'localhost',
        'port'    => 3306,
        'name'    => '',      // 数据库名
        'user'    => '',      // 数据库用户名
        'pass'    => '',      // 数据库密码
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'name'      => 'QuntecHub 项目文件管理系统',
        // 上传文件实际存放目录（绝对路径）。默认放在 public/uploads 下。
        'upload_dir'=> dirname(__DIR__).'/public/uploads',
        // 单文件大小上限（字节）。0 = 不限，受 PHP 自身 upload_max_filesize 限制。
        'max_size'  => 0,
        // 允许上传的扩展名（小写，不含点）。空数组 = 允许全部。
        'allow_ext' => [],
    ],
    'installed' => false,
];
