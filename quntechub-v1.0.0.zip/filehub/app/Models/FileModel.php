<?php
/**
 * 文件主记录模型
 */
class FileModel extends Model
{
    protected static string $table = 'files';

    /** 取某目录下文件 */
    public static function inFolder(int $projectId, int $folderId): array
    {
        $sql = 'SELECT * FROM files WHERE project_id = ? AND folder_id = ? ORDER BY name ASC';
        return Database::run($sql, [$projectId, $folderId])->fetchAll();
    }

    /** 取项目下最近文件 */
    public static function recent(int $limit = 10): array
    {
        $sql = 'SELECT * FROM files ORDER BY created_at DESC LIMIT '.(int) $limit;
        return self::pdo()->query($sql)->fetchAll();
    }

    /** 同名文件（用于版本判定） */
    public static function sameName(int $projectId, int $folderId, string $name): ?array
    {
        $sql = 'SELECT * FROM files WHERE project_id = ? AND folder_id = ? AND name = ? LIMIT 1';
        $row = Database::run($sql, [$projectId, $folderId, $name])->fetch();
        return $row ?: null;
    }

    /** 取某文件的所有标签 */
    public static function tags(int $fileId): array
    {
        $sql = 'SELECT t.* FROM tags t
                INNER JOIN file_tags ft ON ft.tag_id = t.id
                WHERE ft.file_id = ? ORDER BY t.name ASC';
        return Database::run($sql, [$fileId])->fetchAll();
    }

    /** 搜索：按名称/备注/标签 */
    public static function search(string $q): array
    {
        $like = '%'.$q.'%';
        $sql = "SELECT DISTINCT f.* FROM files f
                LEFT JOIN file_tags ft ON ft.file_id = f.id
                LEFT JOIN tags t ON t.id = ft.tag_id
                WHERE f.name LIKE ? OR f.note LIKE ? OR t.name LIKE ?
                ORDER BY f.created_at DESC";
        return Database::run($sql, [$like, $like, $like])->fetchAll();
    }

    /** 磁盘总用量 */
    public static function totalSize(): int
    {
        return (int) self::pdo()->query('SELECT COALESCE(SUM(size),0) FROM files')->fetchColumn();
    }

    public static function countAll(): int
    {
        return (int) self::pdo()->query('SELECT COUNT(*) FROM files')->fetchColumn();
    }
}
