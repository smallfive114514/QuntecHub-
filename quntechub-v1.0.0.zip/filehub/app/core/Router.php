<?php
/**
 * 极简路由器
 * 支持 GET/POST，路径参数 {id}
 */
class Router
{
    private array $routes = [];
    private string $notFound = '';

    public function get(string $pattern, string $action): void { $this->add('GET', $pattern, $action); }
    public function post(string $pattern, string $action): void { $this->add('POST', $pattern, $action); }

    private function add(string $method, string $pattern, string $action): void
    {
        $this->routes[] = [$method, $pattern, $action];
    }

    public function notFound(string $action): void { $this->notFound = $action; }

    public function dispatch(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = $this->path();

        foreach ($this->routes as [$m, $pattern, $action]) {
            if ($m !== $method) {
                continue;
            }
            $regex = $this->compile($pattern);
            if (preg_match($regex, $path, $matches)) {
                $params = [];
                foreach ($matches as $k => $v) {
                    if (!is_int($k)) {
                        $params[$k] = $v;
                    }
                }
                $this->invoke($action, $params);
                return;
            }
        }
        // 404
        if ($this->notFound) {
            http_response_code(404);
            $this->invoke($this->notFound, []);
            return;
        }
        http_response_code(404);
        echo '404 Not Found';
    }

    private function path(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?? '/';
        // 去掉站点子目录前缀
        $base = app_base_url();
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base));
        }
        // 统一为「无前导斜杠、无尾随斜杠」，根路径为空串
        $path = trim($path, '/');
        return $path;
    }

    private function compile(string $pattern): string
    {
        // {name} -> (?P<name>[^/]+)
        $regex = preg_replace('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', '(?P<$1>[^/]+)', $pattern);
        return '#^'.$regex.'$#u';
    }

    private function invoke(string $action, array $params): void
    {
        [$class, $method] = explode('@', $action, 2);
        $controller = new $class();
        $controller->{$method}(...$this->orderParams($method, $class, $params));
    }

    /** 按控制器方法签名顺序填充参数 */
    private function orderParams(string $method, string $class, array $params): array
    {
        $r = new ReflectionMethod($class, $method);
        $ordered = [];
        foreach ($r->getParameters() as $p) {
            $name = $p->getName();
            if (array_key_exists($name, $params)) {
                $ordered[] = $params[$name];
            } elseif ($p->isDefaultValueAvailable()) {
                $ordered[] = $p->getDefaultValue();
            } else {
                $ordered[] = null;
            }
        }
        return $ordered;
    }
}
