<?php
class ErrorController extends Controller
{
    public function notFound(): void
    {
        $this->view('error', ['title' => '页面不存在 · QuntecHub', 'code' => 404, 'message' => '找不到你要的页面。']);
    }
}
