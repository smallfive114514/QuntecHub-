<?php
class DashboardController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $projects = Project::withCounts();
        $recent   = FileModel::recent(8);
        $totalSize = FileModel::totalSize();
        $fileCount = FileModel::countAll();
        $projCount = count($projects);

        $this->view('dashboard', [
            'title'  => '首页 · QuntecHub',
            'projects' => $projects,
            'recent'   => $recent,
            'totalSize' => $totalSize,
            'fileCount' => $fileCount,
            'projCount' => $projCount,
        ]);
    }
}
