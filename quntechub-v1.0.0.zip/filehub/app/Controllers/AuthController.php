<?php
class AuthController extends Controller
{
    public function login(): void
    {
        if (is_logged_in()) {
            redirect('');
        }
        $this->plain('login', ['error' => flash('error')]);
    }

    public function authenticate(): void
    {
        $this->requireCsrf();
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        $row = Database::run('SELECT * FROM admin WHERE username = ? LIMIT 1', [$username])->fetch();
        if (!$row || !password_verify($password, $row['password_hash'])) {
            flash('error', '用户名或密码错误。');
            redirect('login');
        }

        session_regenerate_id(true);
        $_SESSION['admin_id']   = (int) $row['id'];
        $_SESSION['admin_user']  = $row['username'];

        $next = $_POST['next'] ?? '';
        $next = $next !== '' ? ltrim($next, '/') : '';
        // 仅允许相对路径
        redirect($next !== '' ? $next : '');
    }

    public function logout(): void
    {
        $_SESSION = [];
        session_destroy();
        redirect('login');
    }
}
