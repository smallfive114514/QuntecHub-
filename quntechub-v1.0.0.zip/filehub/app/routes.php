<?php
/**
 * 路由定义
 * 格式：方法 路径 => 控制器@方法
 */
return function (Router $r): void {

    // 安装向导（仅未安装时可用）
    $r->get('install', 'InstallController@index');
    $r->post('install', 'InstallController@store');

    // 认证
    $r->get('login', 'AuthController@login');
    $r->post('login', 'AuthController@authenticate');
    $r->get('logout', 'AuthController@logout');

    // 首页
    $r->get('', 'DashboardController@index');

    // 项目
    $r->post('project', 'ProjectController@store');
    $r->post('project/{id}', 'ProjectController@update');
    $r->post('project/{id}/delete', 'ProjectController@delete');
    $r->get('project/{id}', 'ProjectController@show');

    // 文件夹
    $r->post('folder', 'FolderController@store');
    $r->post('folder/{id}', 'FolderController@update');
    $r->post('folder/{id}/delete', 'FolderController@delete');
    $r->get('folder/{id}', 'FolderController@show');

    // 文件
    $r->post('file/upload', 'FileController@upload');
    $r->post('file/{id}', 'FileController@update');
    $r->post('file/{id}/delete', 'FileController@delete');
    $r->post('file/{id}/move', 'FileController@move');
    $r->get('file/{id}/download', 'FileController@download');
    $r->get('file/{id}/raw', 'FileController@raw');
    $r->get('file/{id}/preview', 'FileController@preview');
    $r->get('file/{id}', 'FileController@show');

    // 标签
    $r->post('file/{id}/tags', 'TagController@attach');

    // 版本历史
    $r->get('file/{id}/versions', 'VersionController@index');
    $r->post('file/{id}/version/{vid}/revert', 'VersionController@revert');
    $r->get('file/{id}/version/{vid}/download', 'VersionController@download');
    $r->post('file/{id}/version', 'VersionController@uploadNew');

    // 搜索
    $r->get('search', 'SearchController@index');

    $r->notFound('ErrorController@notFound');
};
