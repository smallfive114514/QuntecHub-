<?php
/**
 * 应用启动引导
 * PHP 8.0+ / MySQL 5.6+
 */
define('BASE_PATH', dirname(__DIR__));

// 错误显示：未安装或调试时显示，否则隐藏
$configFile = BASE_PATH.'/config/config.php';
$config = file_exists($configFile) ? require $configFile : require BASE_PATH.'/config/config.sample.php';

if (!empty($config['debug'])) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', '0');
}

date_default_timezone_set('Asia/Hong_Kong');

// Session 安全设置
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

// 自动加载（无命名空间，新手友好）
spl_autoload_register(function (string $class): void {
    $dirs = ['app/core', 'app/Models', 'app/Controllers'];
    foreach ($dirs as $dir) {
        $file = BASE_PATH.'/'.$dir.'/'.$class.'.php';
        if (is_file($file)) {
            require $file;
            return;
        }
    }
});

require BASE_PATH.'/app/core/helpers.php';

// 计算站点根 URL（兼容放在域名根目录或子目录）
function app_base_url(): string
{
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '/index.php';
    $dir = str_replace('\\', '/', dirname($scriptName));
    if ($dir === '/' || $dir === '.') {
        return '';
    }
    return rtrim($dir, '/');
}
