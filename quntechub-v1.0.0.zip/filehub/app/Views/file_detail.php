<?php /** @var array $file $project $tags $versions $ptype $folderOptions */
$fid = (int) $file['id'];
?>
<nav aria-label="breadcrumb" class="mb-3">
  <ol class="breadcrumb mb-0">
    <li class="breadcrumb-item"><a href="<?= base_url('') ?>">首页</a></li>
    <?php if ($project): ?>
      <li class="breadcrumb-item"><a href="<?= base_url('project/'.(int)$project['id']) ?>"><?= e($project['name']) ?></a></li>
    <?php endif; ?>
    <li class="breadcrumb-item active" aria-current="page"><?= e($file['name']) ?></li>
  </ol>
</nav>

<div class="row g-3">
  <div class="col-lg-8">
    <div class="card p-4 mb-3">
      <div class="d-flex align-items-center mb-3">
        <i class="<?= file_icon($file['extension']) ?> fh-file-icon me-3"></i>
        <div>
          <h5 class="mb-0"><?= e($file['name']) ?></h5>
          <div class="text-muted small">
            <?= format_bytes($file['size']) ?> · <?= e(strtoupper($file['extension']) ?: '文件') ?> ·
            更新于 <?= date('Y-m-d H:i', strtotime($file['updated_at'])) ?>
          </div>
        </div>
      </div>

      <div class="d-flex flex-wrap gap-2 mb-3">
        <?php if ($ptype !== 'download'): ?>
          <a class="btn btn-primary btn-sm" href="<?= base_url('file/'.$fid.'/preview') ?>"><i class="bi bi-eye"></i> 在线预览</a>
        <?php endif; ?>
        <a class="btn btn-outline-secondary btn-sm" href="<?= base_url('file/'.$fid.'/download') ?>"><i class="bi bi-download"></i> 下载</a>
        <a class="btn btn-outline-secondary btn-sm" href="<?= base_url('file/'.$fid.'/versions') ?>"><i class="bi bi-clock-history"></i> 版本历史 (<?= count($versions) ?>)</a>
      </div>

      <!-- 备注 / 重命名 -->
      <form method="post" action="<?= base_url('file/'.$fid) ?>">
        <?= csrf_field() ?>
        <label class="form-label small">文件名</label>
        <input class="form-control mb-3" name="name" value="<?= e($file['name']) ?>">
        <label class="form-label small">备注</label>
        <textarea class="form-control mb-3" name="note" rows="2" maxlength="1000"><?= e($file['note']) ?></textarea>
        <button class="btn btn-primary btn-sm">保存备注</button>
      </form>
    </div>

    <!-- 标签 -->
    <div class="card p-4 mb-3">
      <h6 class="mb-2">标签</h6>
      <?php if ($tags): ?>
        <div class="mb-3">
          <?php foreach ($tags as $t): ?>
            <a class="badge text-bg-light border me-1" href="<?= base_url('search?q='.urlencode($t['name'])) ?>"><?= e($t['name']) ?></a>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="text-muted small mb-3">还没有标签</div>
      <?php endif; ?>
      <form method="post" action="<?= base_url('file/'.$fid.'/tags') ?>" class="d-flex gap-2">
        <?= csrf_field() ?>
        <input class="form-control" name="tags" value="<?= e(implode(', ', array_map(fn($t)=>$t['name'], $tags))) ?>" placeholder="用逗号分隔多个标签，如：合同, 重要">
        <button class="btn btn-outline-primary btn-sm">保存</button>
      </form>
    </div>
  </div>

  <div class="col-lg-4">
    <!-- 移动 -->
    <div class="card p-4 mb-3">
      <h6 class="mb-3">移动到</h6>
      <form method="post" action="<?= base_url('file/'.$fid.'/move') ?>">
        <?= csrf_field() ?>
        <input type="hidden" name="project_id" value="<?= $project ? (int)$project['id'] : 0 ?>">
        <label class="form-label small">目标文件夹（仅当前项目内）</label>
        <select class="form-select mb-3" name="folder_id">
          <option value="0">— 项目根目录 —</option>
          <?php foreach ($folderOptions as $o): ?>
            <option value="<?= $o['id'] ?>" <?= $o['id']===(int)$file['folder_id'] ? 'selected' : '' ?>><?= e($o['label']) ?></option>
          <?php endforeach; ?>
        </select>
        <button class="btn btn-outline-primary btn-sm w-100">移动</button>
      </form>
    </div>

    <!-- 删除 -->
    <div class="card p-4">
      <h6 class="mb-3 text-danger">危险操作</h6>
      <form method="post" action="<?= base_url('file/'.$fid.'/delete') ?>" onsubmit="return confirm('确定删除该文件？历史版本也会一并删除。')">
        <?= csrf_field() ?>
        <button class="btn btn-outline-danger btn-sm w-100"><i class="bi bi-trash"></i> 删除文件</button>
      </form>
    </div>
  </div>
</div>
