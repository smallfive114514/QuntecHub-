<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>安装 QuntecHub</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>body{background:#f4f5f9}.card{border:none;border-radius:14px}.brand{font-weight:700;letter-spacing:.5px}</style>
</head>
<body class="py-5">
<div class="container" style="max-width:560px">
  <div class="text-center mb-4">
    <div class="brand fs-3 text-primary">QuntecHub 项目文件管理系统</div>
    <div class="text-muted small">安装向导 · 跟着填几个框就能用</div>
  </div>
  <div class="card shadow-sm p-4">
    <?php if (!empty($error)): ?>
      <div class="alert alert-danger py-2"><?= e($error) ?></div>
    <?php endif; ?>
    <form method="post" action="<?= base_url('install') ?>">
      <?= csrf_field() ?>
      <h6 class="text-muted mb-3">1. 数据库信息（在宝塔「数据库」里创建好后来填）</h6>
      <div class="row g-2">
        <div class="col-8"><label class="form-label small">数据库地址</label><input class="form-control" name="host" value="<?= e($old['host']) ?>"></div>
        <div class="col-4"><label class="form-label small">端口</label><input class="form-control" name="port" value="<?= e($old['port']) ?>"></div>
      </div>
      <div class="mt-2"><label class="form-label small">数据库名</label><input class="form-control" name="name" value="<?= e($old['name']) ?>" placeholder="例如 quntechub"></div>
      <div class="mt-2"><label class="form-label small">数据库用户名</label><input class="form-control" name="user" value="<?= e($old['user']) ?>"></div>
      <div class="mt-2"><label class="form-label small">数据库密码</label><input class="form-control" type="password" name="pass" autocomplete="new-password"></div>

      <h6 class="text-muted mt-4 mb-3">2. 设置管理员账号</h6>
      <div class="row g-2">
        <div class="col-5"><label class="form-label small">管理员用户名</label><input class="form-control" name="admin_user" value="admin"></div>
        <div class="col-7"><label class="form-label small">管理员密码（至少6位）</label><input class="form-control" type="password" name="admin_pass" autocomplete="new-password"></div>
      </div>

      <button class="btn btn-primary w-100 mt-4">开始安装</button>
    </form>
    <div class="text-muted small mt-3 mb-0">
      提示：如果填的数据库不存在，系统会尝试自动创建；若权限不足，请先在宝塔手动建好数据库再填。
    </div>
  </div>
</div>
</body>
</html>
