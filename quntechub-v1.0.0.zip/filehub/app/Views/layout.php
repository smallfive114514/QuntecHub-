<?php
/** @var array $data 可选数据 */
$success = flash('success');
$error   = flash('error');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($data['title'] ?? 'QuntecHub') ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<style>
:root{--fh:#4B3FE3}
body{background:#f4f5f9;font-family:system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
.navbar-fh{background:#fff;box-shadow:0 1px 6px rgba(0,0,0,.04)}
.brand{font-weight:700;color:var(--fh)}
.card{border:none;border-radius:12px}
.fh-file-icon{font-size:1.4rem;color:var(--fh)}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-fh sticky-top">
  <div class="container-fluid px-3">
    <a class="navbar-brand brand" href="<?= base_url('') ?>"><i class="bi bi-cloud me-1"></i>QuntecHub</a>
    <form class="d-flex mx-auto" role="search" method="get" action="<?= base_url('search') ?>" style="max-width:420px;width:100%">
      <input class="form-control" type="search" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="搜索文件名 / 备注 / 标签…" aria-label="搜索">
    </form>
    <div class="d-flex align-items-center">
      <?php if (!empty($currentUser)): ?>
        <span class="text-muted small me-3 d-none d-sm-inline"><i class="bi bi-person-circle"></i> <?= e($currentUser['username']) ?></span>
        <a class="btn btn-sm btn-outline-secondary" href="<?= base_url('logout') ?>">退出</a>
      <?php else: ?>
        <a class="btn btn-sm btn-outline-secondary" href="<?= base_url('login') ?>">登录</a>
      <?php endif; ?>
    </div>
  </div>
</nav>

<main class="container py-4" style="max-width:1180px">
  <?php if ($success): ?><div class="alert alert-success py-2"><?= e($success) ?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger py-2"><?= e($error) ?></div><?php endif; ?>
  <?= $content ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
