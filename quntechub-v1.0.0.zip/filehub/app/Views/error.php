<?php /** @var int $code @var string $message */ ?>
<div class="text-center py-5">
  <div class="display-5 text-muted"><?= (int)($code ?? 404) ?></div>
  <p class="text-muted mt-2"><?= e($message ?? '页面不存在') ?></p>
  <a class="btn btn-primary mt-2" href="<?= base_url('') ?>">返回首页</a>
</div>
