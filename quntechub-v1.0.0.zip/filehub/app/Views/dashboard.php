<?php /** @var array $projects $recent */
?>
<div class="d-flex align-items-center mb-4">
  <h4 class="mb-0">仪表盘</h4>
</div>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card p-3 text-center">
      <div class="text-muted small">项目</div>
      <div class="fs-4 fw-bold"><?= $projCount ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card p-3 text-center">
      <div class="text-muted small">文件</div>
      <div class="fs-4 fw-bold"><?= $fileCount ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card p-3 text-center">
      <div class="text-muted small">已用空间</div>
      <div class="fs-4 fw-bold"><?= format_bytes($totalSize) ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3 d-flex">
    <a class="card p-3 text-center text-decoration-none text-reset w-100" href="#" data-bs-toggle="modal" data-bs-target="#newProject">
      <i class="bi bi-plus-circle fs-3 text-primary"></i>
      <div class="small">新建项目</div>
    </a>
  </div>
</div>

<div class="d-flex align-items-center mb-3">
  <h5 class="mb-0">项目</h5>
  <button class="btn btn-sm btn-primary ms-3" data-bs-toggle="modal" data-bs-target="#newProject"><i class="bi bi-plus"></i> 新建</button>
</div>

<?php if (!$projects): ?>
  <div class="card p-5 text-center text-muted">
    还没有项目，点「新建」创建第一个吧。
  </div>
<?php else: ?>
  <div class="row g-3">
    <?php foreach ($projects as $p): ?>
      <div class="col-md-4 col-lg-3">
        <a class="card p-3 text-decoration-none text-reset h-100 d-block" href="<?= base_url('project/'.$p['id']) ?>">
          <div class="d-flex align-items-center">
            <span class="me-2" style="width:14px;height:14px;border-radius:4px;background:<?= e($p['color']) ?>;display:inline-block"></span>
            <span class="fw-semibold text-truncate"><?= e($p['name']) ?></span>
          </div>
          <div class="text-muted small text-truncate mt-1"><?= e($p['description'] ?: '暂无描述') ?></div>
          <div class="text-muted small mt-2"><i class="bi bi-file-earmark"></i> <?= (int)$p['file_count'] ?> 个文件 · <?= format_bytes($p['total_size']) ?></div>
        </a>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<div class="d-flex align-items-center mb-3 mt-4">
  <h5 class="mb-0">最近文件</h5>
</div>
<?php if (!$recent): ?>
  <div class="card p-4 text-center text-muted small">还没有文件</div>
<?php else: ?>
  <div class="card">
    <table class="table table-hover mb-0 align-middle">
      <tbody>
      <?php foreach ($recent as $f): ?>
        <tr>
          <td style="width:42px"><i class="<?= file_icon($f['extension']) ?> fh-file-icon"></i></td>
          <td><a class="text-decoration-none" href="<?= base_url('file/'.$f['id']) ?>"><?= e($f['name']) ?></a></td>
          <td class="text-muted small d-none d-md-table-cell"><?= format_bytes($f['size']) ?></td>
          <td class="text-muted small d-none d-lg-table-cell"><?= time_ago(strtotime($f['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>

<!-- 新建项目弹窗 -->
<div class="modal fade" id="newProject" tabindex="-1">
  <div class="modal-dialog">
    <form class="modal-content" method="post" action="<?= base_url('project') ?>">
      <?= csrf_field() ?>
      <div class="modal-header"><h6 class="modal-title">新建项目</h6><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
      <div class="modal-body">
        <label class="form-label small">项目名称</label>
        <input class="form-control mb-3" name="name" required>
        <label class="form-label small">描述（可选）</label>
        <input class="form-control mb-3" name="description">
        <label class="form-label small">颜色标识</label>
        <input type="color" class="form-control form-control-color" name="color" value="#6f6fff">
      </div>
      <div class="modal-footer"><button class="btn btn-primary">创建</button></div>
    </form>
  </div>
</div>
